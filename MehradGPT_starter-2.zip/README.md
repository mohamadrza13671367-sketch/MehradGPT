# MehradGPT (starter)
## Deploy on Render
1. Upload all project files to a GitHub repository (keep `server.js`, `package.json`, `.env.example`, `.gitignore`, `public/`).
2. In Render choose **New + → Web Service**, connect this repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. In Render Environment, add `OPENAI_API_KEY` (secret) and `OPENAI_MODEL` (choose a model enabled for your API account).
6. Deploy. Visit the generated Render URL.
Never put the API key in frontend code or commit `.env`.
