import express from "express";
import OpenAI from "openai";
import path from "path";
import { fileURLToPath } from "url";

const app = express();
app.use(express.json({ limit: "1mb" }));
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_req, res) => res.json({ ok: true, app: "MehradGPT" }));

app.post("/api/chat", async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: "API key is not configured on server." });
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const { message, history = [], tone = "friendly", language = "Persian" } = req.body || {};
    if (!message || typeof message !== "string") return res.status(400).json({ error: "Message is required." });
    const safeHistory = Array.isArray(history) ? history.slice(-12).map(m => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content || "").slice(0, 4000)
    })) : [];
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-6",
      instructions: `You are MehradGPT, a helpful general-purpose assistant. Respond in ${language}. Use a ${tone} tone. Be clear and honest.`,
      input: [...safeHistory, { role: "user", content: message }]
    });
    res.json({ reply: response.output_text || "پاسخی دریافت نشد." });
  } catch (e) {
    console.error("Chat API error:", e?.message || e);
    res.status(500).json({ error: "پاسخ‌گویی با خطا روبه‌رو شد. تنظیمات سرور یا مدل را بررسی کنید." });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`MehradGPT listening on ${port}`));
